<?php
// index.php (controlador de rutas)

require_once 'controllers/AlumnoController.php'; // incluimos la declaración de la Clase AlumnoController
require_once 'controllers/AuthController.php';  // el controlador de autentificación y
require_once 'models/User.php';
require_once 'models/Alumno.php';                 // el modelo de usuarios son cargados al empezar

$controller = new AuthController();  // se crea una instancia de controlador de usuario (que incluye conexión, tabla, y operatoria con usuarios)
$controllerAl = new AlumnoController();
																							 // Simple enrutamiento basado en la URL. Se concentra aquí todo el redireccionamiento
if (!isset($_REQUEST['action'])) {             // la primera vez, entramos para hacer login y no hay en la URL action definida
    $controller->login();
} else {
    switch ($_REQUEST['action']) {             // más adelante, podemos venir desde el interior con una action particular en la url
        case 'login':
            $controller->login();              // si la action fuera login
            break;
        case 'authenticate':
            $controller->authenticate();      // si hay que autenticar
            break;
        case 'index':
            $controllerAl->index();         // si vamos a la página interna de inicio de la aplicación
            break;
        case 'create':
            $controllerAl->create();         // se invoca al método create() de AlumnoController
            break;
        case 'edit':
            $controllerAl->edit();           // se invoca al método edit() de AlumnoController
            break;
        case 'delete':
            $controllerAl->delete();         // se invoca al método delete() de AlumnoController
            break;
        case 'logout':
            $controller->logout();            // si cerramos la sesión
            break;
        default:
            $controller->login();
            break;
    }
}