<?php
    if (!isset($_SESSION['idusuario'])) {
            header('Location: ../index.php');
            exit();
        }
        include 'views/Login.php';
?>

<!-- views/editar.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Alumno</title>

    <style>
        body {
            background: linear-gradient(to bottom, #000000, #00FFFF);
            min-height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            color: #ffffff;
        }

        form {
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(6px);
            padding: 35px 40px;
            border-radius: 18px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 20px 40px rgba(0, 255, 255, 0.25);
        }

        legend {
            font-size: 22px;
            font-weight: 700;
            text-align: center;
            margin-bottom: 25px;
            color: #00eaff;
        }

        label {
            display: block;
            margin-bottom: 18px;
            font-size: 14px;
            color: #cfffff;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            margin-top: 6px;
            padding: 12px 16px;
            border-radius: 25px;
            border: none;
            outline: none;
            font-size: 15px;
        }

        input[type="checkbox"] {
            transform: scale(1.2);
        }

        .checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        button {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 25px;
            border: none;
            cursor: pointer;
            background: linear-gradient(135deg, #000000, #00CFFF);
            color: white;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 207, 255, 0.4);
        }

        .back-link {
            text-align: center;
            margin-top: 18px;
        }

        .back-link a {
            color: #00eaff;
            text-decoration: none;
            font-size: 14px;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <form method="POST" action="index.php?action=edit&id=<?php echo $alumno_data->id; ?>">
        <legend>Editar alumno</legend>

        <input type="hidden" name="id" value="<?php echo $alumno_data->id; ?>">

        <label>
            Nombre
            <input type="text" name="nombre"
                value="<?php echo htmlspecialchars($alumno_data->nombre); ?>" required>
        </label>

        <label>
            Apellidos
            <input type="text" name="apellidos"
                value="<?php echo htmlspecialchars($alumno_data->apellidos); ?>" required>
        </label>

        <label>
            Fecha de nacimiento
            <input type="date" name="fechaNacimiento"
                value="<?php echo htmlspecialchars($alumno_data->fechaNacimiento); ?>" required>
        </label>

        <div class="checkbox">
            <label>Repite</label>
            <input type="checkbox" name="repite"
                <?php echo $alumno_data->repite ? 'checked' : ''; ?>>
        </div>

        <button type="submit" name="update">Actualizar alumno</button>

        <div class="back-link">
            <a href="index.php?action=index">← Volver al listado</a>
        </div>
    </form>

</body>
</html>
