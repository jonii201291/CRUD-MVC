<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <style>
        body {
            background: linear-gradient(to bottom, #000000, #00FFFF);
            min-height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            color: #ffffff;
        }

        /* MENSAJE DE ERROR */
        .error-box {
            background: rgba(211, 47, 47, 0.15);
            border-left: 5px solid #ff5252;
            color: #ffb3b3;
            padding: 14px 18px;
            border-radius: 10px;
            margin-bottom: 20px;
            max-width: 420px;
            width: 100%;
            box-shadow: 0 10px 20px rgba(255, 0, 0, 0.2);
            text-align: center;
            font-weight: 600;
        }

        form {
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(6px);
            padding: 35px 40px;
            border-radius: 18px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 20px 40px rgba(0, 255, 255, 0.25);
        }

        legend {
            font-size: 22px;
            font-weight: 700;
            text-align: center;
            margin-bottom: 25px;
            color: #00eaff;
        }

        fieldset {
            border: none;
            padding: 0;
        }

        input {
            width: 100%;
            margin-bottom: 18px;
            padding: 12px 16px;
            font-size: 15px;
            border-radius: 25px;
            border: none;
            outline: none;
        }

        input:focus {
            box-shadow: 0 0 0 2px rgba(0, 207, 255, 0.5);
        }

        button {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 25px;
            border: none;
            cursor: pointer;
            background: linear-gradient(135deg, #000000, #00CFFF);
            color: white;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 207, 255, 0.4);
        }

    </style>
</head>

<body>

<?php
if (!empty($_SESSION['error'])) {
    echo '<div class="error-box">' . htmlspecialchars($_SESSION['error']) . '</div>';
    unset($_SESSION['error']);
}
?>

<form action="index.php?action=authenticate" method="POST">
    <fieldset>
        <legend>Iniciar sesión</legend>

        <input type="text" name="idusuario" placeholder="Usuario" required>
        <input type="password" name="password" placeholder="Contraseña" required>

        <button type="submit" name="login">Ingresar</button>
    </fieldset>
</form>

</body>
</html>
