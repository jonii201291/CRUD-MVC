
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Alumnos (MVC)</title>
    <style>
        /* Body general */
        body{
            background: linear-gradient(to bottom, black, #00FFFF);
            min-height: 100vh;
            margin: 0;        
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            color: #fff;
        }


        /* Mensajes */
        .message {
            position: relative;
            background: rgba(0, 207, 255, 0.15);
            border-top: 4px solid #00eaff;
            color: #e0ffff;
            padding: 14px;
            margin: 30px auto 0;
            max-width: 800px;
            text-align: center;
            border-radius: 10px;
            font-weight: 600;
            box-shadow: 0 8px 20px rgba(0, 255, 255, 0.2);
        }

        /* Tabla */
        table {
            position: relative;
            clear: both;
            border-collapse: collapse;
            width: 80%;
            margin: auto;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            border-radius: 10px;
            overflow: hidden;
            background: linear-gradient(to bottom, #ff99ff, #ffb3ff);
            color: black;
            text-align: center;
        }

        th, td {
            padding: 12px 15px;
        }

        thead {
            background-color: #ff66ff;
            font-weight: bold;
        }

        tbody tr:nth-child(even) {
            background-color: #ffccff;
        }

        caption {
            color: white;
            font-size: 2em;
        }

        hr {
            position: relative;
            clear: both;
            
        }

        .imageTable {
            width: 50px;
            height: 50px;
            mix-blend-mode: multiply;
        }

        .inser{
            width: 50px;
            height: 50px;
            position: fixed;
            top: 7%; /* distancia desde arriba */
            left: 10%; /* distancia desde la izquierda */
            border-radius: 100%;
            border: 2px solid white;
            cursor: pointer;
            box-shadow: 0 3px 6px rgba(194, 226, 211, 0.77);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .inser:hover {
            background-color: #66ffff;
            transform: scale(1.05);
        }

        .out{
            width: 50px;
            height: 50px;
            position: fixed;
            top: 7%; /* distancia desde arriba */
            right: 10%; /* distancia desde la izquierda */
            border-radius: 100%;
            border: 2px solid white;
            cursor: pointer;
            box-shadow: 0 3px 6px rgba(194, 226, 211, 0.77);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .out:hover {
            background-color: #66ffff;
            transform: scale(1.05);
        }

        </style>
</head>

<body>

    <?php
 
    if (isset($_GET['message'])): ?>
        <div class="message">
            <?php
            if ($_GET['message'] == 'created') echo 'Alumno creado correctamente.';
            if ($_GET['message'] == 'updated') echo 'Alumno actualizado correctamente.';
            if ($_GET['message'] == 'deleted') echo 'Alumno eliminado correctamente.';
            if ($_GET['message'] == 'logout') echo 'Sesión cerrada correctamente.';
            ?>
        </div>
    <?php endif; ?>

    <a href="index.php?action=create" ><img class="inser" src="imagenes/add.png" alt="insertar"></a>
    <a href="index.php?action=logout"><img class="out" src="imagenes/logout.png"></a>
 

    <table>
        <caption>Listado de alumnos</caption>
        <thead>
            <tr>
                <th>Num Alumno</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Fecha Nacimiento</th>
                <th>Repite</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if(empty($alumnos)){
                header('Location: index.php?action=login');
                exit();
            }

            foreach ($alumnos as $alumno): ?><!-- alumno es una colección de filas de la tabla -->
                <tr>
                    <td><?php echo $alumno['id']; ?></td>
                    <td><?php echo htmlspecialchars($alumno['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($alumno['apellidos']); ?></td>
                    <td><?php echo htmlspecialchars($alumno['fechaNacimiento']); ?></td>
                    <td><?php echo $alumno['repite'] ? 'Sí' : 'No'; ?></td>
                    <td>
                        <!-- en la última celda incluimos los botones para ir a borrar o editar una fila -->
                        <a href="index.php?action=edit&id=<?php echo $alumno['id']; ?>"><img class="imageTable" src="imagenes/modd.png" alt="editar"></a> |
                        <a href="index.php?action=delete&id=<?php echo $alumno['id']; ?>" onclick="return confirm('¿Estás seguro?');"><img class="imageTable" src="imagenes/del.png" alt="eliminar"></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>