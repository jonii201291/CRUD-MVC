<?php
// controllers/AuthController.php
include_once 'config/database.php';
include_once 'models/User.php';

class AuthController                                   // la clase AuthController contiene un objeto usuario (el que autentica)
{
    private $userModel;

    public function __construct()                     // aquí lo crea
    {
        $this->userModel = new Usuario();
    }

    public function login()                           // aquí ejecuta el login (en realidad, la vista login)
    {
        if (isset($_SESSION['idusuario'])) {
            header('Location: index.php?action=index');
            exit();
        }
        include 'views/Login.php';
    }

    public function authenticate()                    // aquí confronta con la base de datos
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['idusuario'];
            $password = $_POST['password'];

            if ($this->userModel->login($username, $password)) {
                // Autenticación exitosa, iniciar sesión y redirigir al enrutador para que éste envíe al dashboard-inicio
                $_SESSION['idusuario'] = $username;

                $_SESSION['mensaje'] = "Bienvenido, $username 👋";
                $_SESSION['mensaje_tipo'] = "success";
                header('Location: index.php?action=index'); // redirige al AlumnoController::index()
                exit();
               
            } else {
                // Autenticación fallida, recargar login con error que mostraría mensaje
                $_GET['error'] = "Usuario o contraseña incorrectos.";
                $_SESSION['mensaje_tipo'] = "error";
                header ('Location: index.php?action=login&error=Usuario o contraseña incorrectos.');
                exit();
            }
        }
  
    }
    public function listar()
    {
        
        // Verificar si el usuario ha iniciado sesión
        if (!isset($_SESSION['idusuario'])) {
            header('Location: index.php?action=login');
            exit();
        }
        // Carga la vista del listar (página de bienvenida)
        include 'views/listar.php';
    }

    public function logout()
    {
        session_unset();
        session_destroy();

        $_SESSION['mensaje'] = "Sesión cerrada correctamente";
        $_SESSION['mensaje_tipo'] = "info";

        header('Location: index.php?action=login');
        exit();
        
    }
}